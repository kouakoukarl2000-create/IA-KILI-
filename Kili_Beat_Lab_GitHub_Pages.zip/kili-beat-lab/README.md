# Kili€ Beat Lab

Prototype mobile de beat maker noir et or, conçu pour Android et l'export audio vers BandLab.

## Fonctionnalités
- Tempo réglable de 70 à 180 BPM
- Swing
- Presets de patterns trap / dark trap / afro-trap / drill / chill
- Séquenceur 16 pas : kick, clap/snare, closed hat, open hat, 808, lead
- Sections intro, couplet, refrain
- Lecture dans le navigateur
- Export WAV stéréo local
- Sauvegarde de pattern JSON
- Interface responsive et support PWA de base

## Important
Ce prototype n'est pas encore un modèle d'IA générative comme Suno. Il synthétise des sons dans le navigateur et construit un beat à partir de patterns. Il n'envoie aucun fichier vers un serveur.

## Publier gratuitement sur GitHub Pages
1. Crée un dépôt public sur GitHub nommé `kili-beat-lab`.
2. Téléverse `index.html`, `manifest.webmanifest`, `sw.js` et `README.md` à la racine du dépôt.
3. Dans le dépôt, ouvre **Settings → Pages**.
4. Sous **Build and deployment**, choisis **Deploy from a branch**.
5. Choisis la branche `main` et le dossier `/ (root)`, puis enregistre.
6. Attends la publication et ouvre l'URL affichée par GitHub Pages.

## Utiliser sur Android
- Ouvre le lien GitHub Pages dans Chrome.
- Pour l'installer comme application web, ouvre le menu ⋮ puis **Ajouter à l'écran d'accueil** si l'option est proposée.
- Active des cases dans le séquenceur, puis appuie sur **Exporter WAV**.
- Dans BandLab, importe le WAV comme fichier audio.

## Limites connues
- Export WAV mono/stéréo : une seule piste stéréo complète, pas encore de stems séparés.
- La section Intro/Couplet/Refrain sélectionne des réglages, mais l'export actuel répète le pattern choisi sur la longueur sélectionnée ; il ne construit pas encore un arrangement multi-section automatique.
- Le moteur audio est synthétique et simple, sans samples enregistrés ni modèle IA intégré.
- Certains navigateurs Android peuvent demander une interaction pour autoriser l'audio.
